# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['cipher_yx2625']

package_data = \
{'': ['*']}

install_requires = \
['coverage>=6.1.1,<7.0.0',
 'pandas>=1.3.4,<2.0.0',
 'pytest>=6.2.5,<7.0.0',
 'twine>=3.5.0,<4.0.0']

setup_kwargs = {
    'name': 'cipher-yx2625',
    'version': '0.1.0',
    'description': 'simple Python package to cipher textual data',
    'long_description': "# cipher_yx2625\n\nA basic text ciphering package\n\n## Installation\n\nMake sure you are downloading this package with **Python3.9 or above** \n```bash\n$ pip install cipher_yx2625\n```\n\n## Usage\n\nThis package is somewhat simple. It applies caesarian ciphering method to shift text by a specified number of positions right (if the shift parameter is positive) or left (if the shift parameter is negative). \n\n```python:\nimport cipher_yx2625 from cipher_yx2625\n\n#c all cipher function from cipher_yx2625. \ncipher_yx2625.cipher('Harry', 3) // => 'KduuB'\ncipher_yx2625.cipher('H=rmione',-10) // => 'x=hcYedU'\n```\n\n## Contributing\n\nInterested in contributing? Check out the contributing guidelines. Please note that this project is released with a Code of Conduct. By contributing to this project, you agree to abide by its terms.\n\n## License\n\n`cipher_yx2625` was created by Ye (Connie) Xu. It is licensed under the terms of the MIT license.\n\n## Credits\n\n`cipher_yx2625` was created with [`cookiecutter`](https://cookiecutter.readthedocs.io/en/latest/) and the `py-pkgs-cookiecutter` [template](https://github.com/py-pkgs/py-pkgs-cookiecutter).\n",
    'author': 'connixu',
    'author_email': 'y.connie.xu@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://github.com/QMSS-G5072-2021/cipher_xu_ye_connie',
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
